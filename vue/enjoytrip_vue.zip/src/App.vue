<template>
  <div id="app">
    <navi-bar></navi-bar>
    <router-view></router-view>
  </div>
</template>

<script>
// import BoardList from "@/components/board/BoardList.vue";
import NaviBar from "@/components/layout/HeaderBar.vue";

export default {
  name: "App",
  components: {
    NaviBar,
    // BoardList,
  },
};
</script>

<style>
</style>

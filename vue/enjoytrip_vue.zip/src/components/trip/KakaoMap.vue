<template>
  <div>
    <div id="map"></div>
    <!-- <div class="button-group">
      <button @click="changeSize(0)">Hide</button>
        <button @click="changeSize(800)">show</button>
        <button @click="displayMarker(markerPositions1)">marker set 1</button>
        <button @click="displayMarker(markerPositions2)">marker set 2</button>
        <button @click="displayMarker([])">marker set 3 (empty)</button>
        <button @click="displayInfoWindow">infowindow</button>
    </div> -->
  </div>
</template>
  
<script>

export default {
  name: "kakaoMap",
  data() {
    return {
      map: null,
      markerPositions1: [
        [33.452278, 126.567803],
        [33.452671, 126.574792],
        [33.451744, 126.572441],
      ],
      markerPositions2: [
        [37.499590490909185, 127.0263723554437],
        [37.499427948430814, 127.02794423197847],
        [37.498553760499505, 127.02882598822454],
        [37.497625593121384, 127.02935713582038],
        [37.49629291770947, 127.02587362608637],
        [37.49754540521486, 127.02546694890695],
        [37.49646391248451, 127.02675574250912],
      ],
      markers: [],
      infowindow: null,
      customOverlay: null,
    };
  },
  mounted() {
    if (window.kakao && window.kakao.maps) {
      this.initMap();
    } else {
      const script = document.createElement("script");
      /* global kakao */


      script.src =
        "//dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=8ce68fe8da91c9f36d81376b8131b49e&libraries=services,clusterer,drawing";
      script.onload = () => kakao.maps.load(this.initMap);

      document.head.appendChild(script);
    }
  },
  methods: {
    initMap() {
      const container = document.getElementById("map");
      const options = {
        center: new kakao.maps.LatLng(37.500613, 127.036431),
        level: 5,
      };

      //지도 객체를 등록합니다.
      //지도 객체는 반응형 관리 대상이 아니므로 initMap에서 선언합니다.
      this.map = new kakao.maps.Map(container, options);
    },
    changeSize(size) {
      const container = document.getElementById("map");
      container.style.width = `${size}px`;
      container.style.height = `${size}px`;
      this.map.relayout();
    },
    displayMarker(attrList) {
      for (var i = 0; i < attrList.length; i++) {
        let content = attrList[i];
        let curContentId = attrList[i].contentId;
        console.log(curContentId)
        console.log(attrList[i].latitude)
        console.log(attrList[i].longitude)

        // 마커를 생성합니다
        var marker = new kakao.maps.Marker({
          map: this.map, // 마커를 표시할 지도
          position: new kakao.maps.LatLng(attrList[i].latitude, attrList[i].longitude),
          title: attrList[i].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
          // image: normalMarkerImage, // 마커 이미지
          clickable: true
        });

        const tmp = this;
        (marker) => marker.setMap(this.map);
        marker.addListener('click', () => {
          console.log(content)
          tmp.drawCustomOverlay(content)
        })
      }

    },
    
    displayInfoWindow() {
      if (this.infowindow && this.infowindow.getMap()) {
        //이미 생성한 인포윈도우가 있기 때문에 지도 중심좌표를 인포윈도우 좌표로 이동시킨다.
        this.map.setCenter(this.infowindow.getPosition());
        return;
      }

      var iwContent = '<div style="padding:5px;">Hello World!</div>', // 인포윈도우에 표출될 내용으로 HTML 문자열이나 document element가 가능합니다
        iwPosition = new kakao.maps.LatLng(33.450701, 126.570667), //인포윈도우 표시 위치입니다
        iwRemoveable = true; // removeable 속성을 ture 로 설정하면 인포윈도우를 닫을 수 있는 x버튼이 표시됩니다

      this.infowindow = new kakao.maps.InfoWindow({
        map: this.map, // 인포윈도우가 표시될 지도
        position: iwPosition,
        content: iwContent,
        removable: iwRemoveable,
      });

      this.map.setCenter(iwPosition);
    },

    moveCenter(trip) {
      this.map.setLevel(2);
      this.map.setCenter(new kakao.maps.LatLng(trip.latitude, trip.longitude));
    },

    drawCustomOverlay(content) {
      var tmp = `<div class="wrap">
    <div class="info">
      <div class="title">
        ${content.title}
        <div class="close" @click="closeOverlay" title="닫기"></div>
      </div>
      <div class="body">
        <div class="desc">
          <div class="address1">${content.address1}</div>
          <div class="address2">${content.address2}</div>
        </div>
      </div>
    </div>
  </div>`;

      const container = document.createElement('div');
      container.innerHTML = tmp;

      const closeButton = container.querySelector('.close');
      closeButton.addEventListener('click', this.closeOverlay);

      this.customOverlay = new kakao.maps.CustomOverlay({
        content: container,
        position: new kakao.maps.LatLng(content.latitude, content.longitude),
        yAnchor: 1,
        zIndex: 3
      });

      this.customOverlay.setMap(this.map);
    },


    closeOverlay() {
      console.log("================================================")
      this.customOverlay.setMap(null);
    }
  }
};
</script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#map {
  width: 700px;
  height: 700px;
}

.button-group {
  margin: 10px 0px;
}

button {
  margin: 0 3px;
}
</style>
  



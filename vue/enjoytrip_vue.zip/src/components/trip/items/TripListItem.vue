

<script>
export default {
  name: "BoardListItem",
  props: {
    attrList: [],
  },
};
</script>

<style></style>

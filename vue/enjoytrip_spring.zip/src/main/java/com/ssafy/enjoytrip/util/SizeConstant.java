package com.ssafy.enjoytrip.util;

public class SizeConstant {

	public final static int LIST_SIZE = 10; //한 페이지당 글의 개수
	public final static int NAVIGATION_SIZE = 10; //네비게이션 범위 
	
}

package com.ssafy.enjoytrip.model.dto;

import lombok.Data;

@Data
public class HotPlaceDto {
	private int contentId;
	private String uid;
	private int likes;
}
